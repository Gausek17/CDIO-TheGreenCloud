<?php

$servidor='localhost';
$usuario='root';
$password='';
$db='bd_tgc';
$conexion = mysqli_connect($servidor,$usuario,$password,$db);

?>